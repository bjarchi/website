#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "dictionary-len.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s words\n", argv[0]);
        exit(1);
    }

    FILE *f = fopen(argv[1], "r");
    char buf[512];
    char *s;
    int line = 0, len, r;
    while ((s = fgets(buf, 512, f)) != NULL) {
        line++;
        len = strlen(s);
        if (s[len-1] == '\n')
            s[--len] = 0;
        r = match(s, len);
        if (r != line) {
            printf("%s: %d\n", s, r);
            exit(1);
        }
    }
    fclose(f);
    return 0;
}
